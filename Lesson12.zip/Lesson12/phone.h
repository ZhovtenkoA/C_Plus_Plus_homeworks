#ifndef PHONE_H
#define PHONE_H

#include <QString>

class Phone
{
public:
    QString model, brand;
    qint32 memory, ram;
};

#endif // PHONE_H
